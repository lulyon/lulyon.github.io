<?php
	phpinfo(); 
?>
